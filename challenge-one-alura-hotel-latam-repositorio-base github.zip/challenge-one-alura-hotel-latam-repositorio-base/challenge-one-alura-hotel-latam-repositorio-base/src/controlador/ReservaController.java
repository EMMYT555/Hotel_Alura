package controlador;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import clases.Reserva;
import clasesBD.ReservaBD;
import factory.ConexionFactory;

public class ReservaController {
	final private ReservaBD reservaBD;

    public ReservaController() throws SQLException {
    	Connection conexion = new ConexionFactory().recuperaConexion();
        this.reservaBD = new ReservaBD(conexion);
    }

    public int insertarReserva(Reserva reserva) {
        return reservaBD.insertarReserva(reserva);
    }

    public List<Reserva> listar() {
        return reservaBD.listar();
    }
    public int eliminar(Integer id) throws SQLException {
        HuespedController huespedController = new HuespedController();
        huespedController.actualizarReservaId(id);
        return reservaBD.eliminar(id);
    }

    public int modificar(Reserva reserva) {
        return reservaBD.modificar(reserva);
    }
    public List<Reserva> buscar(Integer id) {
        return reservaBD.buscar(id);
    }
    public List<Reserva> buscar(String apellido) {
        return reservaBD	.buscar(apellido);
    }
}
