package controlador;

import java.sql.Connection;
import java.sql.SQLException;

import clases.Usuario;
import clasesBD.UsuarioBD;
import factory.ConexionFactory;

public class UsuarioController {
	final private UsuarioBD usuarioBD;

    public UsuarioController() throws SQLException {
    	Connection conexion = new ConexionFactory().recuperaConexion();
        this.usuarioBD = new UsuarioBD(conexion);
    }

    public Usuario login(String usuario, String contrasena) {
        return usuarioBD.login(usuario, contrasena);
    }
}
