package controlador;

import clasesBD.HuespedBD;
import factory.ConexionFactory;
import clases.Huesped;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class HuespedController {
    final private  HuespedBD huespedBD;

    public HuespedController() throws SQLException {
    	Connection conexion = new ConexionFactory().recuperaConexion();
        this.huespedBD = new HuespedBD(conexion);
    }
    public int insertarHuesped(Huesped huesped) {
        return huespedBD.insertarHuesped(huesped);
    }

    public List<Huesped> listar() {
        return huespedBD.listar();
    }

    public int modificar(Huesped huesped) {
        return huespedBD.modificar(huesped);
    }

    public int eliminar(Integer id) {
        return huespedBD.eliminar(id);
    }

    public void actualizarReservaId(Integer idReserva) {
    	huespedBD.actualizarReserva(idReserva);
    }

}